"use client";

import { useI18n } from "@/components/I18nProvider";
import { wedding } from "@/lib/wedding-data";

export function MapSection() {
  const { t } = useI18n();

  return (
    <div className="space-y-10">
      <header className="text-center space-y-2">
        <div className="divider-ornament" aria-hidden>
          <span>🍋</span>
          <span>✦</span>
          <span>🌿</span>
        </div>
        <h2 className="section-title">{t.map.title}</h2>
        <p className="section-subtitle">{t.map.subtitle}</p>
      </header>

      <iframe
        title={wedding.venue.name}
        src={wedding.venue.googleMapsUrl}
        width="100%"
        height="380"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        className="border-0 w-full block"
        style={{ background: "var(--leaf-50)", borderRadius: "12px" }}
      />

      <div className="text-center space-y-4">
        <div>
          <p
            className="font-script text-3xl"
            style={{ color: "var(--leaf-700)" }}
          >
            {wedding.venue.name}
          </p>
          <p className="mt-1" style={{ color: "var(--ink-soft)" }}>
            {wedding.venue.address}
          </p>
        </div>

        <p className="text-sm italic" style={{ color: "var(--ink-muted)" }}>
          🚗 {t.map.parking}
          <br />
          🏙️ {t.map.landmark}
        </p>

        <a
          href={wedding.venue.directionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-primary inline-flex"
        >
          {t.map.directions} ↗
        </a>
      </div>
    </div>
  );
}
