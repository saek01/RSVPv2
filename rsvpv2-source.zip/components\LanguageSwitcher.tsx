"use client";

import { useState, useRef, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useI18n } from "./I18nProvider";

export function LanguageSwitcher() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const pathname = usePathname();
  const router = useRouter();
  const { locale } = useI18n();

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function switchLocale(target: "en" | "ms") {
    if (target === locale) {
      setOpen(false);
      return;
    }
    document.cookie = `locale=${target}; path=/; max-age=${60 * 60 * 24 * 365}`;
    const segments = pathname.split("/");
    if (segments[1] === locale) {
      segments[1] = target;
    } else {
      segments.splice(1, 0, target);
    }
    router.push(segments.join("/") || `/${target}`);
    setOpen(false);
  }

  return (
    <div ref={ref} className="fixed top-4 right-4 z-50">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="lang-pill"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <span aria-hidden>🌐</span>
        <span className="uppercase">{locale}</span>
        <span aria-hidden className="text-xs">▾</span>
      </button>

      {open && (
        <div className="lang-menu glass">
          <button
            type="button"
            onClick={() => switchLocale("en")}
            className={locale === "en" ? "active" : ""}
          >
            English
          </button>
          <button
            type="button"
            onClick={() => switchLocale("ms")}
            className={locale === "ms" ? "active" : ""}
          >
            Bahasa Melayu
          </button>
        </div>
      )}
    </div>
  );
}
