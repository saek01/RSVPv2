"use client";

import { useI18n } from "@/components/I18nProvider";
import { wedding } from "@/lib/wedding-data";

export function ContactSection() {
  const { t } = useI18n();

  return (
    <div className="space-y-12">
      <header className="text-center space-y-2">
        <div className="divider-ornament" aria-hidden>
          <span>🍋</span>
          <span>✦</span>
          <span>🌿</span>
        </div>
        <h2 className="section-title">{t.contact.title}</h2>
        <p className="section-subtitle">{t.contact.subtitle}</p>
      </header>

      <div className="grid sm:grid-cols-2 gap-12">
        <FamilyBlock
          eyebrow={t.contact.brideFamily}
          father={t.contact.brideFather}
          mother={t.contact.brideMother}
          contact={wedding.bride.contact}
        />
        <FamilyBlock
          eyebrow={t.contact.groomFamily}
          father={t.contact.groomFather}
          mother={t.contact.groomMother}
          contact={wedding.groom.contact}
        />
      </div>
    </div>
  );
}

function FamilyBlock({
  eyebrow,
  father,
  mother,
  contact,
}: {
  eyebrow: string;
  father: string;
  mother: string;
  contact: string;
}) {
  return (
    <div className="text-center space-y-4">
      <p
        className="text-xs uppercase tracking-[0.3em]"
        style={{ color: "var(--leaf-700)" }}
      >
        {eyebrow}
      </p>
      <div className="space-y-1" style={{ color: "var(--ink)" }}>
        <p style={{ fontFamily: "var(--font-display)", fontSize: "1.25rem" }}>
          {father}
        </p>
        <p style={{ color: "var(--ink-muted)" }}>&amp;</p>
        <p style={{ fontFamily: "var(--font-display)", fontSize: "1.25rem" }}>
          {mother}
        </p>
      </div>
      <a
        href={`tel:${contact.replace(/\s+/g, "")}`}
        className="btn btn-ghost inline-flex"
      >
        📞 {contact}
      </a>
    </div>
  );
}
