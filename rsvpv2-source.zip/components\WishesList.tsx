"use client";

import { useEffect, useState } from "react";
import { useI18n } from "./I18nProvider";

export type StoredWish = {
  name: string;
  phone?: string;
  message: string;
  date: string;
};

const STORAGE_KEY = "rsvp.wishes";

export function WishesList() {
  const { t } = useI18n();
  const [wishes, setWishes] = useState<StoredWish[] | null>(null);

  useEffect(() => {
    // localStorage is client-only; first paint shows a placeholder.
    /* eslint-disable react-hooks/set-state-in-effect */
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      const parsed: StoredWish[] = raw ? JSON.parse(raw) : [];
      setWishes(parsed.sort((a, b) => b.date.localeCompare(a.date)));
    } catch {
      setWishes([]);
    }
    /* eslint-enable react-hooks/set-state-in-effect */
  }, []);

  if (wishes === null) {
    return (
      <div className="text-sm py-4 text-center" style={{ color: "var(--ink-muted)" }}>
        <span className="inline-block animate-pulse">…</span>
      </div>
    );
  }

  if (wishes.length === 0) {
    return (
      <p className="italic py-4 text-center" style={{ color: "var(--ink-muted)" }}>
        {t.info.wishesEmpty}
      </p>
    );
  }

  return (
    <div className="wishes-scroller">
      <ul className="space-y-0 pt-8 pb-8">
        {wishes.map((w, i) => (
          <li
            key={`${w.date}-${i}`}
            className="py-6"
            style={{
              borderTop: i === 0 ? "none" : "1px solid var(--hairline)",
            }}
          >
            <p
              className="text-lg italic whitespace-pre-wrap"
              style={{
                fontFamily: "var(--font-display)",
                color: "var(--ink)",
              }}
            >
              {w.message}
            </p>
            <p
              className="mt-2 text-xs uppercase tracking-[0.25em]"
              style={{ color: "var(--leaf-700)" }}
            >
              — {w.name}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function readStoredWishes(): StoredWish[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as StoredWish[]) : [];
  } catch {
    return [];
  }
}

export function appendWish(wish: StoredWish): void {
  const existing = readStoredWishes();
  const next = [...existing, wish];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}
